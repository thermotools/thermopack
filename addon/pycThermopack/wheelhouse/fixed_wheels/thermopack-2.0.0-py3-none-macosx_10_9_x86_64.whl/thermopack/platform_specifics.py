# Module for platform specific stuff. Automatically generated.
# Timestamp : 2022-11-15T13:58:18.693457


def get_platform_specifics():
    pf_specifics = {}
    pf_specifics["os_id"] = "darwin"
    pf_specifics["prefix"] = ""
    pf_specifics["module"] = ""
    pf_specifics["postfix"] = ""
    pf_specifics["postfix_no_module"] = ""
    pf_specifics["dyn_lib"] = ""
    return pf_specifics
