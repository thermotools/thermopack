# Module for platform specific stuff. Automatically generated.
# Timestamp : 2024-02-22T09:05:02.856769


DIFFERENTIAL_RETURN_MODE = 'v2'


def get_platform_specifics():
    pf_specifics = {}
    pf_specifics["os_id"] = "win"
    pf_specifics["prefix"] = ""
    pf_specifics["module"] = ""
    pf_specifics["postfix"] = ""
    pf_specifics["postfix_no_module"] = ""
    pf_specifics["dyn_lib"] = ""
    pf_specifics["diff_return_mode"] = "v2"
    return pf_specifics
